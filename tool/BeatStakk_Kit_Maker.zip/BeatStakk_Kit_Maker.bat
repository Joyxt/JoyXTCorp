@echo off
:: Force la console en UTF-8 pour gerer les accents proprement
chcp 65001 >nul
:: Force le script a travailler dans son propre dossier
cd /d "%~dp0"
setlocal enabledelayedexpansion

echo [SYSTEM] Script initialized successfully.
title BeatStakk Kit Creator

echo ==========================================
echo       BEATSTAKK KIT CREATOR UTILITY
echo ==========================================
echo.

:: 1. Verification de la presence des fichiers WAV
set count=0
for %%F in (*.wav) do (
    set /a count+=1
    set "file!count!=%%F"
)

if %count% LSS 8 (
    echo [ERROR] You need at least 8 .wav files in this folder.
    echo Found only %count% file^(s^).
    echo Please add your audio samples here and run this script again.
    echo.
    pause
    exit /b
)

:: 2. Etape 1 - Nom du Kit
:AskKitName
echo.
set /p KIT_NAME="Enter kit name (max 10 chars): "
if "!KIT_NAME!"=="" (
    echo [ERROR] Kit name cannot be empty.
    goto AskKitName
)
:: Limite a 10 caracteres
set "KIT_NAME=!KIT_NAME:~0,10!"
set "KIT_NAME=!KIT_NAME:"=!"
:: Remplacer les espaces par des tirets du bas pour le nom du fichier ZIP
set "FILE_NAME=!KIT_NAME: =_!"

:: 3. Etape 2 - Nom des Samples (Pads)
echo.
echo Please enter a short name (max 7 chars) for your 8 pads.
echo E.g., KICK, SNARE, HIHAT...
echo.

for /L %%I in (1,1,8) do (
    :AskPad%%I
    set "PAD_NAME="
    set /p PAD_NAME="Name for pad %%I [!file%%I!]: "
    if "!PAD_NAME!"=="" (
        echo [ERROR] Pad name cannot be empty.
        goto AskPad%%I
    )
    
    :: 1. Retrait des guillemets
    set "PAD_NAME=!PAD_NAME:"=!"

    :: 2. Nettoyage des accents
    set "PAD_NAME=!PAD_NAME:é=E!"
    set "PAD_NAME=!PAD_NAME:è=E!"
    set "PAD_NAME=!PAD_NAME:ê=E!"
    set "PAD_NAME=!PAD_NAME:ë=E!"
    set "PAD_NAME=!PAD_NAME:à=A!"
    set "PAD_NAME=!PAD_NAME:â=A!"
    set "PAD_NAME=!PAD_NAME:ä=A!"
    set "PAD_NAME=!PAD_NAME:ô=O!"
    set "PAD_NAME=!PAD_NAME:ö=O!"
    set "PAD_NAME=!PAD_NAME:î=I!"
    set "PAD_NAME=!PAD_NAME:ï=I!"
    set "PAD_NAME=!PAD_NAME:ù=U!"
    set "PAD_NAME=!PAD_NAME:û=U!"
    set "PAD_NAME=!PAD_NAME:ü=U!"
    set "PAD_NAME=!PAD_NAME:ç=C!"

    :: 3. Conversion en MAJUSCULES (Methode Batch stricte)
    for %%X in ("a=A" "b=B" "c=C" "d=D" "e=E" "f=F" "g=G" "h=H" "i=I" "j=J" "k=K" "l=L" "m=M" "n=N" "o=O" "p=P" "q=Q" "r=R" "s=S" "t=T" "u=U" "v=V" "w=W" "x=X" "y=Y" "z=Z") do (
        set "PAD_NAME=!PAD_NAME:%%~X!"
    )

    :: 4. Coupure nette a 7 caracteres maximum
    set "PAD_NAME=!PAD_NAME:~0,7!"

    :: Enregistrement du nom final
    set "label%%I=!PAD_NAME!"
)

:: 4. Etape 3 - Confirmation
echo.
echo ==========================================
echo SUMMARY
echo Kit Name: !KIT_NAME!
echo File Output: !FILE_NAME!.beatstakk
echo Pads: !label1!, !label2!, !label3!, !label4!, !label5!, !label6!, !label7!, !label8!
echo ==========================================
echo.
set /p CONFIRM="Process kit creation? (Y/N): "
if /i not "!CONFIRM!"=="Y" (
    echo Operation cancelled by user.
    pause
    exit /b
)

:: 5. Generation Automatique
echo.
echo [1/4] Preparing files...
if exist temp_build rd /s /q temp_build
mkdir temp_build

:: Copie et renommage strict des fichiers en 1.wav, 2.wav, etc.
for /L %%I in (1,1,8) do (
    copy "!file%%I!" "temp_build\%%I.wav" >nul
)

echo [2/4] Generating metadata.json...
(
echo {
echo   "format": "BEATSTAKK_KIT",
echo   "version": 1,
echo   "kitName": "!KIT_NAME!",
echo   "padLabels": [
echo     "!label1!",
echo     "!label2!",
echo     "!label3!",
echo     "!label4!",
echo     "!label5!",
echo     "!label6!",
echo     "!label7!",
echo     "!label8!"
echo   ]
echo }
) > temp_build\metadata.json

echo [3/4] Compressing into archive...
if exist "!FILE_NAME!.zip" del "!FILE_NAME!.zip"
if exist "!FILE_NAME!.beatstakk" del "!FILE_NAME!.beatstakk"
powershell -NoProfile -Command "Compress-Archive -Path 'temp_build\*' -DestinationPath '!FILE_NAME!.zip' -Force"

echo [4/4] Finalizing .beatstakk file...
ren "!FILE_NAME!.zip" "!FILE_NAME!.beatstakk"
rd /s /q temp_build

echo.
echo ==========================================
echo SUCCESS! Your kit '!FILE_NAME!.beatstakk' is ready!
echo You can now import it directly into BeatStakk.
echo ==========================================
pause